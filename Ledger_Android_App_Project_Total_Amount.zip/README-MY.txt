ငွေစာရင်း Android App - တည်ဆောက်နည်း

ပါဝင်သည့်အရာများ
- DATE / BANK / NAME / AMOUNT စာရင်းထည့်ခြင်း
- TOTAL KG နှင့် RATE ထည့်ခြင်း
- AMOUNT = TOTAL KG × RATE အလိုအလျောက်တွက်ခြင်း
- ADVANCE = စာရင်းထဲရှိ AMOUNT အားလုံးပေါင်းခြင်း
- BALANCE = AMOUNT - ADVANCE
- ဖုန်းထဲတွင် Offline သိမ်းဆည်းခြင်း
- CSV ထုတ်ခြင်း၊ Print/PDF ပြုလုပ်ခြင်း

APK ရယူရန် (အလွယ်ဆုံး)
1. ဒီ ZIP ကို ကွန်ပျူတာတွင် ဖြည်ပါ။
2. GitHub တွင် repository အသစ်တစ်ခုဖန်တီးပြီး ဖိုင်အားလုံး upload လုပ်ပါ။
3. Actions tab ကိုဖွင့်ပါ။
4. "Build Android APK" workflow ကိုရွေးပြီး Run workflow နှိပ်ပါ။
5. ပြီးသွားလျှင် ledger-app-debug artifact ကို download လုပ်ပြီး ZIP ဖြည်ပါ။
6. app-debug.apk ကို Android ဖုန်းသို့ပို့ပါ။
7. APK ကိုနှိပ်ပြီး Install လုပ်ပါ။ Android က မေးလျှင် ယုံကြည်ရသော source မှ install ခွင့်ပြုပါ။

Android Studio ဖြင့်လည်း project ကိုဖွင့်ပြီး Build > Build Bundle(s) / APK(s) > Build APK(s) ကိုရွေးနိုင်သည်။

မှတ်ချက်
- ဒီပတ်ဝန်းကျင်မှာ Android SDK မရှိသဖြင့် APK ကို ဒီနေရာမှာ compile မလုပ်နိုင်ပါ။
- ဒီ ZIP သည် APK ထုတ်နိုင်ရန် Android project အပြည့်အစုံဖြစ်သည်။
- ဒေတာများသည် app ၏ local storage ထဲတွင်ရှိသည်။ App data ရှင်းခြင်း သို့မဟုတ် uninstall လုပ်ခြင်းမပြုမီ CSV export လုပ်ထားပါ။
